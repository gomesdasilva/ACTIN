from .actin import main

main()
